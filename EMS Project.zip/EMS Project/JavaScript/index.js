// custom.js
$(document).ready(function(){
    // Add custom JavaScript code here
    console.log("Custom JS loaded");
    
    // Example: Form validation
    $('form').on('submit', function(e){
        e.preventDefault();
        const email = $('input[type="email"]').val();
        if(email){
            alert("Subscribed successfully!");
        } else {
            alert("Please enter a valid email address.");
        }
    });
});
